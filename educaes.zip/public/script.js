function saludar() {
  alert("¡Hola desde Educaes!");
}